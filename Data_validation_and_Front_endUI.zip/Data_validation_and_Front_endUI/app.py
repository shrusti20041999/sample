import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load data
data = pd.read_csv('updated_data.csv')
data = data.drop(columns=['Unnamed: 9','tags'])
data.dropna(inplace=True)
data.drop_duplicates(inplace=True)

# Combine text
data['search_text'] = (
    data['details'].fillna('') + " " + 
    data['benefits'].fillna('') + " " + 
    data['eligibility'].fillna('') + " " +
    data['schemeCategory'].fillna('')
)

# Vectorize once
vectorizer = TfidfVectorizer(stop_words='english')
tfidf_matrix = vectorizer.fit_transform(data['search_text'])

# --- UI ---
st.title("🤖YojanaMitraAI")

# Sidebar for profile
st.sidebar.header("User Profile")
name = st.sidebar.text_input("Name")
age = st.sidebar.number_input("Age", 1, 100)
gender = st.sidebar.selectbox("Gender", ["Male", "Female", "Other"])
occupation = st.sidebar.text_input("Occupation")
location = st.sidebar.text_input("Location")

# Save profile (fake persistence)
if st.sidebar.button("Save Profile"):
    st.session_state.profile = {
        "name": name,
        "age": age,
        "gender": gender,
        "occupation": occupation,
        "location": location
    }
    st.sidebar.success("Profile Saved!")

# Chat UI
st.subheader("💬 Chat")

user_input = st.text_input("Ask your need (e.g. financial help for study)")

if st.button("Get Recommendation"):
    if "profile" not in st.session_state:
        st.warning("Please save profile first!")
    else:
        profile = st.session_state.profile
        
        query = f"{profile['occupation']} {profile['location']} {user_input}"
        
        profile_vec = vectorizer.transform([query])
        scores = cosine_similarity(profile_vec, tfidf_matrix)
        best_index = scores.argmax()
        result = data.iloc[best_index]

        st.markdown("### ✅ Recommended Scheme")
        st.write("**Scheme Name:**", result['scheme_name'])
        st.write("**Category:**", result['schemeCategory'])
        st.write("**Benefits:**", result['benefits'])