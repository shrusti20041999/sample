Store ur file
